﻿
using Ejemplo01;
using System.Configuration;

string sqlServerConnectionString =
    ConfigurationManager.ConnectionStrings["constring"].ConnectionString;

IRepository<Customer> repository = new CustomerRepository(sqlServerConnectionString);

IEnumerable<Customer> customers = repository.GetAll();
Console.WriteLine("Clientes de Sql Server");
foreach (Customer customer in customers)
    Console.WriteLine($"Id: {customer.Id}, " +
        $"FirstName: {customer.FirstName}, " + $"LastName: {customer.LastName}");

Console.WriteLine("***********************************");

IRepository<Inventory> repository1 = new InventoryRepository(sqlServerConnectionString);

IEnumerable<Inventory> inventories= repository1.GetAll();
Console.WriteLine("Animales de Sql Server");
foreach (Inventory inventory in inventories)
    Console.WriteLine($"Id: {inventory.Id}, " + $"MakeId: {inventory.MakeId}, " +
        $"Color: {inventory.Color}, " + $"PetName: {inventory.PetName}");