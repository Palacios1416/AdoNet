﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejemplo01
{
    public class InventoryRepository : IRepository<Inventory>
    {
        private readonly string _connectionString;

        public InventoryRepository(string connectionString)
        {
            _connectionString = connectionString;
        }

        public IEnumerable<Inventory> GetAll()
        {
            List<Inventory> inventories = new List<Inventory>();
            try
            {
                using (SqlConnection connection = new SqlConnection(_connectionString))
                {
                    connection.Open();
                    SqlCommand command = new SqlCommand("SELECT * FROM Inventory", connection);
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            Inventory inventory = new Inventory
                            {
                                Id = Convert.ToInt32(reader["Id"]),
                                MakeId = Convert.ToInt32(reader["MakeId"]),
                                Color = reader["Color"].ToString(),
                                PetName = reader["PetName"].ToString(),
                              
                            };
                            inventories.Add(inventory);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error al recuperar clientes: " + ex);
            }
            return inventories;
        }
    }
}
